package blogquiz;

public interface Procedure {
    void run();
}
