package lambda.lambda02;

import lambda.Procedure;

public class ProcedureMain01 {
    public static void main(String[] args) {
        Procedure procedure = new Procedure() {
            @Override
            public void run() {
                System.out.println("hello!! lambda");
            }
        };

        procedure.run();
    }
}
