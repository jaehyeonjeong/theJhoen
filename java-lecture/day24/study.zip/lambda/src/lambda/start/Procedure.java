package lambda.start;

public interface Procedure {
    void run();
}
