package lambda.lambda01;

// 함수가 두개 있으면 람다로 만들지 못하고, 람다 할당이 안된다.
public interface NotSamInterface {
    void run();
    void go();
}
