package lambda.lambda01;

public interface Generic <T>{
    void genetic(T exp, T dis);
}
