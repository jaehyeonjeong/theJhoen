package lambda;

public interface Procedure {
    void run();
}
